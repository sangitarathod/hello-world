<?php
/**
 * Created by PhpStorm.
 * User: allaerd
 * Date: 25/03/16
 * Time: 23:19
 */

namespace Allaerd\Export;


interface exportInterface
{
    public function start ();
}