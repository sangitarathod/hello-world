<?php

/**
 * Created by PhpStorm.
 * User: allaerd
 * Date: 25/03/16
 * Time: 23:12
 */

namespace Allaerd\Export;

interface writerInterface
{
    public function write ($data);
}