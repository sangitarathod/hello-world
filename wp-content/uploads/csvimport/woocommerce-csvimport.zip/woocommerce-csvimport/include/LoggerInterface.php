<?php

namespace Allaerd;

interface Logger
{
    public function log ($data);

}