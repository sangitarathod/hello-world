<?php
/**
 * Created by PhpStorm.
 * User: allaerd
 * Date: 22/08/16
 * Time: 09:51
 */
?>
<div class="wrap">
    <?php include 'header.php'; ?>
    <?php

    allaerd_importer()->dd($lines);

    ?>


</div>
