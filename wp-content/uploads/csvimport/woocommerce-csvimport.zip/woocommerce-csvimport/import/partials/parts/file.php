<?php
/**
 * Created by PhpStorm.
 * User: allaerd
 * Date: 22/08/16
 * Time: 10:10
 */
?>
<input name="file" type="file">
