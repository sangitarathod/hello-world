<?php
/**
 * Created by PhpStorm.
 * User: allaerd
 * Date: 22/08/16
 * Time: 08:58
 */
?>
<select name="separator">
    <option value=";">;</option>
    <option value=",">,</option>
    <option value="|">|</option>
    <option value="\t">tab</option>
    <option value="">other</option>
</select>
<input name="other_separator" type="text" placeholder="other placeholder">
