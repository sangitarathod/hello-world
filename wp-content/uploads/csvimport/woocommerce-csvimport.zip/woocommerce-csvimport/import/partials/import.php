<?php
/**
 * Created by PhpStorm.
 * User: allaerd
 * Date: 20/08/16
 * Time: 21:09
 */
?>
<div class="wrap">
    <?php include 'notice.php'; ?>
    <?php include 'header.php'; ?>

    <?php include "form-import.php"; ?>

</div>